package com.example.gagan.lbbtask.listeners;


/**
 * Created by Gagan on 5/28/2016.
 */
public interface AuthenticationListener {
    void onCodeReceived(String code);
}
