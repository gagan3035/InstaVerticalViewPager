package com.example.gagan.lbbtask.constants;

/**
 * Created by Gagan on 5/28/2016.
 */
public class Constants {

    public static String CLIENT_ID	= "dd45fa23389b41f7885ec4e3d4724a2f";
    public static String CLIENT_SECRET	= "7e3f47bcb62a490a8795a74ad952f3ab";
    public static String REDIRECT_URI	= "http://localhost";
    public static final String BASE_URL = "https://api.instagram.com";
    public static final String AUTORISATION_CODE = "authorization_code";
    public static final String HASHTAG = "ifoundawesome";
    public static final int PAGES_COUNT = 4;


}

