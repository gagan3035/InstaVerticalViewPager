package com.example.gagan.lbbtask.views;

import android.app.ProgressDialog;
import android.content.Intent;
import android.os.Bundle;
import android.support.v7.app.AppCompatActivity;
import android.util.Log;
import android.view.Window;
import android.widget.EditText;

import com.example.gagan.lbbtask.listeners.AuthenticationListener;
import com.example.gagan.lbbtask.R;
import com.example.gagan.lbbtask.constants.Constants;
import com.example.gagan.lbbtask.model.TokenResponse;
import com.example.gagan.lbbtask.services.ServiceGenerator;

import java.io.IOException;

import retrofit2.Call;
import retrofit2.Callback;
import retrofit2.Response;

/**
 * Created by Gagan on 5/28/2016.
 */
public class LoginActivity extends AppCompatActivity implements AuthenticationListener {

    private ProgressDialog mSpinner;
    AuthenticationDialog dialog;
    EditText mText;
    String mAuthToken;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.layout_activity_login);
        mSpinner = new ProgressDialog(this);
        mSpinner.requestWindowFeature(Window.FEATURE_NO_TITLE);
        mSpinner.setMessage("Loading...");
      //  mSpinner.show();
        dialog = new AuthenticationDialog(LoginActivity.this, this);
        dialog.show();
    }

    @Override
    public void onCodeReceived(String code) {
        //mText = (EditText)findViewById(R.id.editText);
        mSpinner.show();
//        if(code!= null){
//            dialog.dismiss();
//
//        }

        final Call<TokenResponse> accessToken =  ServiceGenerator.createTokenService().getAccessToken(Constants.CLIENT_ID,Constants.CLIENT_SECRET,Constants.REDIRECT_URI, Constants.AUTORISATION_CODE,code);
        accessToken.enqueue(new Callback<TokenResponse>() {
            @Override
            public void onResponse(Call<TokenResponse> call, Response<TokenResponse> response) {

                if(response.isSuccessful()){
                    mAuthToken = response.body().getAccess_token();
                    Intent intent = new Intent(LoginActivity.this, InstagramActivity.class);
                    Log.d("access_tocken",mAuthToken);
                    intent.putExtra("AUTH_TOKEN", mAuthToken);
                    dialog.dismiss();
                    mSpinner.dismiss();
                    startActivity(intent);
                    finish();

                }else{
                    try {
                        mText.setText(response.errorBody().string());
                        mSpinner.dismiss();
                    } catch (IOException e) {
                        e.printStackTrace();
                    }

                }
            }


            @Override
            public void onFailure(Call<TokenResponse> call, Throwable t) {
                mText.setText("failure");
                finish();
            }
        });


    }

    @Override
    public void onBackPressed() {
        super.onBackPressed();
        finish();
    }
}
