package com.example.gagan.lbbtask.views;

import android.app.ProgressDialog;
import android.content.Intent;
import android.os.Bundle;
import android.support.v4.view.ViewPager;
import android.support.v7.app.AppCompatActivity;
import android.util.Log;

import com.example.gagan.lbbtask.R;
import com.example.gagan.lbbtask.VerticalViewPager;
import com.example.gagan.lbbtask.adapter.HomeScreenPagerAdapter;
import com.example.gagan.lbbtask.constants.Constants;
import com.example.gagan.lbbtask.model.Picture;
import com.example.gagan.lbbtask.services.ServiceManager;

import org.json.JSONArray;
import org.json.JSONObject;

import java.io.BufferedReader;
import java.io.InputStreamReader;
import java.util.ArrayList;
import java.util.List;

import okhttp3.ResponseBody;
import retrofit2.Call;
import retrofit2.Callback;
import retrofit2.Response;

/**
 * Created by Gagan on 5/28/2016.
 */
public class InstagramActivity extends AppCompatActivity {
    String mAuthToken;
    VerticalViewPager verticalViewPager;
    HomeScreenPagerAdapter homeScreenPagerAdapter;

    List<Picture> mPictures= new ArrayList<>();
    private String mMaxId, mMinId;


    private ProgressDialog mProgressDialog;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.layout_activity_instagram);

        Intent intent = getIntent();
        mAuthToken = intent.getStringExtra("AUTH_TOKEN");

        getTagResults(Constants.HASHTAG, "", "");

    }

    private void initViewpager(ArrayList<Picture> pictures) {
        mPictures.addAll(pictures);
        verticalViewPager = (VerticalViewPager) findViewById(R.id.vertical_viewpager);
        homeScreenPagerAdapter = new HomeScreenPagerAdapter(getApplicationContext(), mPictures);
        if (verticalViewPager != null && !mPictures.isEmpty()) {
            verticalViewPager.setAdapter(homeScreenPagerAdapter);
            verticalViewPager.setOffscreenPageLimit(Constants.PAGES_COUNT);
            verticalViewPager.setOnPageChangeListener(new ViewPager.OnPageChangeListener() {
                @Override
                public void onPageScrolled(int position, float positionOffset, int positionOffsetPixels) {

                }

                @Override
                public void onPageSelected(int position) {
                    if (position == mPictures.size()*(0.7) ) {
                        getTagResults(Constants.HASHTAG, mMaxId, mMinId);
                    }
                }

                @Override
                public void onPageScrollStateChanged(int state) {

                }
            });
        }

    }

//"631477962.1fb234f.f7c5cda97c7f4df983b1c764f066ed37"
//"3249369591.dd45fa2.8dc881c8d2c24ef8a5b1951b0cd272b0"
    private void getTagResults(String query, String minId, String maxId) {
            showPD();
        final ArrayList<Picture> Pictures = new ArrayList<Picture>();

        Call<ResponseBody> response = ServiceManager.createService().getResponse(query, "631477962.1fb234f.f7c5cda97c7f4df983b1c764f066ed37", minId, maxId);
        response.enqueue(new Callback<ResponseBody>() {
            @Override
            public void onResponse(Call<ResponseBody> call, Response<ResponseBody> response) {
                if (response.isSuccessful()) {
                    hidePD();


                    StringBuilder sb = new StringBuilder();
                    try {
                        BufferedReader reader = new BufferedReader(new InputStreamReader(response.body().byteStream()));
                        String line;

                        while ((line = reader.readLine()) != null) {
                            sb.append(line);
                        }

                        JSONObject tagResponse = new JSONObject(sb.toString());
                        Log.e("response",sb.toString());

                        for (int i = 0; i < tagResponse.length() - 2; i++) {
                            JSONObject pagination = tagResponse.getJSONObject("pagination");

                      //      mMaxId = pagination.getString("next_max_id");
                            mMinId = pagination.getString("next_min_id");

                            JSONObject meta = tagResponse.getJSONObject("meta");
                            JSONArray data = tagResponse.getJSONArray("data");

                            for (int j = 0; j < data.length(); j++) {

                                JSONArray tags = data.getJSONObject(j).getJSONArray("tags");


                                JSONObject images = data.getJSONObject(j).getJSONObject("images").getJSONObject("low_resolution");


                                Picture picture = new Picture();
                                picture.setURL(images.getString("url"));
                                Pictures.add(picture);

                            }

                        }


                    } catch (Exception e) {
                        e.printStackTrace();
                    }


                }
                if (verticalViewPager == null) {
                    initViewpager(Pictures);
                } else {
                    homeScreenPagerAdapter.addData(Pictures);
                    homeScreenPagerAdapter.notifyDataSetChanged();
                }
            }

            @Override
            public void onFailure(Call<ResponseBody> call, Throwable t) {

                t.printStackTrace();
            }

        });


    }

    private void showPD() {

        if (mProgressDialog == null) {
            mProgressDialog = new ProgressDialog(this);
            mProgressDialog.setMessage("Loading...");
            mProgressDialog.setCancelable(false);
            mProgressDialog.setCanceledOnTouchOutside(false);
            mProgressDialog.show();
        }
    }

    private void hidePD() {
        if (mProgressDialog != null) {
            mProgressDialog.dismiss();
            mProgressDialog = null;
        }

    }
}
